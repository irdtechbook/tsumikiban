# A collection of prh rules [![CircleCI](https://circleci.com/gh/prh/rules.svg?style=svg)](https://circleci.com/gh/prh/rules)

[in japanese](https://github.com/prh/rules/blob/master/README.ja.md)
