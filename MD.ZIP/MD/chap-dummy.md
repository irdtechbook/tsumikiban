# ワンストップふりかえり

ふりかえりましょう

## ふりかえった

画像はこう貼る。

![イベントキービジュアル](images/chap-dummy/img.png)

* Retrospective
* Refrective
* 他もあるよ。

## 参加はこちら

イベントページ[^event]はこちら。

[^event]: ここから入ってね。https://retrospective.connpass.com/event/203149/
